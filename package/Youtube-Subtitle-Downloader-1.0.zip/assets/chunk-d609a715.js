const t="yt-sub-ext",o=`${t}-output-format`,a=`${t}-msg`,e=["TRANSCRIPT-OF-TITLE","TITLE-TRANSCRIPT","TITLE"],s=e[2],n="text";export{s as a,e as b,n as c,a as d,t as e,o};
